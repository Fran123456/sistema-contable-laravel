module.exports = {
    plugins: {
        autoprefixer: {},
    },
};
