<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Log extends Model
{
    use HasFactory;
    protected $table = 'log';
    protected $fillable = [
       'usuario_id','modulo','opcion','accion','empresa_id'
    ];

    public function usuario(){
        return $this->belongsTo(User::class, 'usuario_id');
    }
}
